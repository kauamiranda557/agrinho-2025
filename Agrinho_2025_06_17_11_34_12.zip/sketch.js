// Variáveis Globais
let cenaAtual = 'fazenda'; // 'fazenda' ou 'cidade'

let personagem; // Objeto para o personagem principal
let dinheiro = 0;
let inventarioTrigo = 0; // Quantidade de trigo no inventário

let trigoPlantado = []; // Array para armazenar objetos de trigo

let pessoasCidade = []; // Array para armazenar objetos de pessoas na cidade

// Constantes para cores
const COR_CEU_FAZENDA = [135, 206, 235];
const COR_GRAMA_FAZENDA = [124, 252, 0];
const COR_SOL = [255, 255, 0];
const COR_PORTAL_CIDADE = [0, 0, 255, 150];

const COR_CEU_CIDADE = [135, 206, 250];
const COR_RUA_CIDADE = [100];
const COR_PREDIO = [150];
const COR_MERCADO_SINAL = [255, 0, 0];
const COR_JANELA = [100, 100, 200];
const COR_PORTAL_FAZENDA = [0, 255, 0, 150];

function setup() {
  createCanvas(800, 600);
  personagem = new Personagem(width / 2, height / 2, 30); // Cria o personagem

  // Inicializa algumas pessoas na cidade
  for (let i = 0; i < 5; i++) {
    pessoasCidade.push(new PessoaCidade(random(50, width - 50), random(height / 2 + 50, height - 50)));
  }
}

function draw() {
  background(220); // Cor de fundo padrão

  if (cenaAtual === 'fazenda') {
    desenharFazenda();
  } else if (cenaAtual === 'cidade') {
    desenharCidade();
  }

  personagem.desenhar();
  personagem.mover();
  checarTransicoes();

  // Desenha o HUD (Dinheiro e Inventário)
  fill(0);
  textSize(16);
  textAlign(LEFT);
  text(`Dinheiro: $${dinheiro}`, 10, 20);
  text(`Trigo: ${inventarioTrigo}`, 10, 40);
}

// ====================================================================================================
// CLASSES E OBJETOS
// ====================================================================================================

// Classe Personagem
class Personagem {
  constructor(x, y, tamanho) {
    this.x = x;
    this.y = y;
    this.tamanho = tamanho;
    this.velocidade = 5;
  }

  desenhar() {
    fill(255, 0, 0); // Cor do personagem (vermelho)
    ellipse(this.x, this.y, this.tamanho, this.tamanho);
  }

  mover() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.velocidade;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.velocidade;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.velocidade;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.velocidade;
    }

    // Limitar o personagem dentro da tela
    this.x = constrain(this.x, this.tamanho / 2, width - this.tamanho / 2);
    this.y = constrain(this.y, this.tamanho / 2, height - this.tamanho / 2);
  }
}

// Classe Trigo (para plantação)
class Trigo {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.estagio = 0; // 0: semente, 1: broto, 2: maduro
    this.tempoPlantado = millis(); // Guarda o tempo em que foi plantado
    this.tempoCrescimento = 5000; // Tempo para amadurecer (5 segundos)
  }

  desenhar() {
    if (this.estagio === 0) {
      // Semente (ponto pequeno)
      fill(139, 69, 19);
      ellipse(this.x, this.y, 5, 5);
    } else if (this.estagio === 1) {
      // Broto (pequeno verde)
      fill(0, 150, 0);
      rect(this.x, this.y - 10, 5, 10);
    } else if (this.estagio === 2) {
      // Maduro (amarelo)
      fill(218, 165, 32);
      rect(this.x, this.y - 30, 10, 30);
      rect(this.x - 5, this.y - 20, 20, 5); // Cabeça do trigo
    }
  }

  atualizar() {
    if (this.estagio < 2 && millis() - this.tempoPlantado > this.tempoCrescimento) {
      this.estagio++;
      this.tempoPlantado = millis(); // Reinicia o contador para o próximo estágio
    }
  }
}

// Classe Pessoa na Cidade (NPC)
class PessoaCidade {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.tamanho = 20;
    this.velocidade = random(0.5, 2);
    this.direcaoX = random([-1, 1]); // -1 para esquerda, 1 para direita
    this.direcaoY = random([-1, 1]); // -1 para cima, 1 para baixo
    this.tempoMudancaDirecao = millis();
    this.intervaloMudanca = random(1000, 5000); // Muda de direção a cada 1 a 5 segundos
  }

  desenhar() {
    fill(random(100, 200), random(100, 200), random(100, 200)); // Cor aleatória para cada pessoa
    ellipse(this.x, this.y, this.tamanho, this.tamanho); // Corpo
    fill(0);
    ellipse(this.x, this.y - this.tamanho / 2, this.tamanho / 2, this.tamanho / 2); // Cabeça
  }

  mover() {
    this.x += this.velocidade * this.direcaoX;
    this.y += this.velocidade * this.direcaoY;

    // Inverte a direção se atingir as bordas da tela ou um tempo limite
    if (this.x < 0 || this.x > width) {
      this.direcaoX *= -1;
    }
    if (this.y < height / 2 || this.y > height) { // Movimento restrito à parte inferior da tela
      this.direcaoY *= -1;
    }

    if (millis() - this.tempoMudancaDirecao > this.intervaloMudanca) {
      this.direcaoX = random([-1, 1]);
      this.direcaoY = random([-1, 1]);
      this.tempoMudancaDirecao = millis();
      this.intervaloMudanca = random(1000, 5000);
    }
  }
}

// ====================================================================================================
// FUNÇÕES DE DESENHO DAS CENAS
// ====================================================================================================

function desenharFazenda() {
  // Céu
  fill(COR_CEU_FAZENDA[0], COR_CEU_FAZENDA[1], COR_CEU_FAZENDA[2]);
  rect(0, 0, width, height / 2);
  // Grama
  fill(COR_GRAMA_FAZENDA[0], COR_GRAMA_FAZENDA[1], COR_GRAMA_FAZENDA[2]);
  rect(0, height / 2, width, height / 2);

  // Sol
  fill(COR_SOL[0], COR_SOL[1], COR_SOL[2]);
  ellipse(width - 80, 80, 100, 100);

  // Animais (formas simples)
  // Vaca
  fill(139, 69, 19);
  rect(150, height - 100, 60, 40);
  ellipse(180, height - 100, 30, 30); // Cabeça

  // Galinha
  fill(255, 255, 255);
  ellipse(300, height - 70, 30, 20);
  triangle(310, height - 70, 320, height - 60, 310, height - 60); // Bico

  // Desenha e atualiza o trigo
  for (let i = 0; i < trigoPlantado.length; i++) {
    trigoPlantado[i].atualizar();
    trigoPlantado[i].desenhar();
  }

  // Área de transição para a cidade
  fill(COR_PORTAL_CIDADE[0], COR_PORTAL_CIDADE[1], COR_PORTAL_CIDADE[2], COR_PORTAL_CIDADE[3]);
  rect(width - 70, height / 2 - 50, 50, 100);
  fill(255);
  textSize(12);
  textAlign(CENTER);
  text('Ir para a Cidade', width - 45, height / 2 + 10);

  // Instruções de plantio e colheita
  fill(0);
  text('Pressione \'P\' para plantar trigo (se tiver semente)', width / 2, 50);
  text('Pressione \'C\' para colher trigo maduro', width / 2, 70);
}

function desenharCidade() {
  // Ruas (cinza)
  fill(COR_RUA_CIDADE[0]);
  rect(0, height / 2, width, height / 2);
  // Céu
  fill(COR_CEU_CIDADE[0], COR_CEU_CIDADE[1], COR_CEU_CIDADE[2]);
  rect(0, 0, width, height / 2);

  // Prédio simples (Mercado)
  fill(COR_PREDIO[0]);
  rect(width / 2 - 100, height / 2 - 150, 200, 250);
  fill(COR_MERCADO_SINAL[0], COR_MERCADO_SINAL[1], COR_MERCADO_SINAL[2]);
  textSize(24);
  textAlign(CENTER);
  text('MERCADO', width / 2, height / 2 - 100);

  // Janelas do mercado
  fill(COR_JANELA[0], COR_JANELA[1], COR_JANELA[2]);
  rect(width / 2 - 70, height / 2 - 100, 30, 30);
  rect(width / 2 + 40, height / 2 - 100, 30, 30);

  // Prédio Banco
  fill(180, 180, 0); // Amarelo escuro
  rect(100, height / 2 - 120, 100, 200);
  fill(0);
  textSize(18);
  text('BANCO', 150, height / 2 - 80);
  fill(200);
  rect(135, height / 2 - 30, 30, 40); // Porta

  // Prédio Genérico (Loja de roupas?)
  fill(100, 150, 200); // Azul claro
  rect(width - 200, height / 2 - 100, 150, 180);
  fill(0);
  textSize(18);
  text('LOJA', width - 125, height / 2 - 60);
  fill(200);
  rect(width - 155, height / 2 - 20, 30, 40); // Porta


  // Área de transição para a fazenda
  fill(COR_PORTAL_FAZENDA[0], COR_PORTAL_FAZENDA[1], COR_PORTAL_FAZENDA[2], COR_PORTAL_FAZENDA[3]);
  rect(20, height / 2 - 50, 50, 100);
  fill(0);
  textSize(12);
  textAlign(CENTER);
  text('Ir para a Fazenda', 45, height / 2 + 10);

  // Desenha e move as pessoas na cidade
  for (let i = 0; i < pessoasCidade.length; i++) {
    pessoasCidade[i].mover();
    pessoasCidade[i].desenhar();
  }

  // Instruções de interação na cidade
  fill(0);
  text('Pressione \'V\' perto do mercado para vender trigo', width / 2, 50);
  text('Pressione \'D\' perto do banco para Depositar dinheiro (futuro)', width / 2, 70);
}

// ====================================================================================================
// FUNÇÕES DE LÓGICA DO JOGO
// ====================================================================================================

function checarTransicoes() {
  if (cenaAtual === 'fazenda') {
    // Checar se o personagem está na área de transição para a cidade
    if (dist(personagem.x, personagem.y, width - 45, height / 2) < 60) { // Distância para o centro do portal
      cenaAtual = 'cidade';
      // Posicionar o personagem em uma área segura na nova cena
      personagem.x = 100;
      personagem.y = height / 2;
    }
  } else if (cenaAtual === 'cidade') {
    // Checar se o personagem está na área de transição para a fazenda
    if (dist(personagem.x, personagem.y, 45, height / 2) < 60) {
      cenaAtual = 'fazenda';
      // Posicionar o personagem em uma área segura na nova cena
      personagem.x = width - 100;
      personagem.y = height / 2;
    }
  }
}

function keyPressed() {
  if (cenaAtual === 'fazenda') {
    if (key === 'p' || key === 'P') {
      // Plantar trigo
      // Verifica se o personagem está em uma área de plantio (abaixo da metade da tela)
      if (personagem.y > height / 2 + 50) {
        trigoPlantado.push(new Trigo(personagem.x, personagem.y));
        console.log('Trigo plantado!');
      } else {
        console.log('Você só pode plantar na área da fazenda!');
      }
    } else if (key === 'c' || key === 'C') {
      // Colher trigo
      for (let i = trigoPlantado.length - 1; i >= 0; i--) {
        let t = trigoPlantado[i];
        if (t.estagio === 2 && dist(personagem.x, personagem.y, t.x, t.y) < personagem.tamanho + 10) {
          inventarioTrigo++;
          trigoPlantado.splice(i, 1); // Remove o trigo colhido
          console.log('Trigo colhido! Inventário:', inventarioTrigo);
          break; // Colhe apenas um por vez
        }
      }
    }
  } else if (cenaAtual === 'cidade') {
    if (key === 'v' || key === 'V') {
      // Vender trigo no mercado
      // Verifica se o personagem está perto do mercado
      if (dist(personagem.x, personagem.y, width / 2, height / 2 - 25) < 150) { // Distância ao centro do mercado
        if (inventarioTrigo > 0) {
          let precoTrigo = 5; // Preço por unidade de trigo
          dinheiro += inventarioTrigo * precoTrigo;
          inventarioTrigo = 0; // Zera o inventário após a venda
          console.log('Trigo vendido! Dinheiro:', dinheiro);
        } else {
          console.log('Você não tem trigo para vender!');
        }
      } else {
        console.log('Você precisa estar perto do mercado para vender!');
      }
    } else if (key === 'd' || key === 'D') {
      // Depositar dinheiro no banco (funcionalidade futura)
      if (dist(personagem.x, personagem.y, 150, height / 2 - 50) < 100) { // Perto do banco
        console.log('Você está no banco. O que você gostaria de fazer com seu dinheiro? (Funcionalidade em desenvolvimento)');
      } else {
        console.log('Você precisa estar perto do banco para interagir!');
      }
    }
  }
}